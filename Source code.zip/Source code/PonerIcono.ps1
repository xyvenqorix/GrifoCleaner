param(
    [Parameter(Mandatory = $true)][string]$Exe,
    [Parameter(Mandatory = $true)][string]$Ico
)
$ErrorActionPreference = 'Stop'

$code = @'
using System;
using System.IO;
using System.Runtime.InteropServices;

public static class IconInjector
{
    [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
    static extern IntPtr BeginUpdateResource(string file, bool deleteExisting);
    [DllImport("kernel32.dll", SetLastError = true)]
    static extern bool UpdateResource(IntPtr h, IntPtr type, IntPtr name, ushort lang, byte[] data, uint size);
    [DllImport("kernel32.dll", SetLastError = true)]
    static extern bool EndUpdateResource(IntPtr h, bool discard);

    public static void Inject(string exe, string ico)
    {
        byte[] d = File.ReadAllBytes(ico);
        int count = BitConverter.ToUInt16(d, 4);
        if (count < 1 || BitConverter.ToUInt16(d, 2) != 1)
            throw new Exception("El archivo .ico no es valido.");

        IntPtr h = BeginUpdateResource(exe, false);
        if (h == IntPtr.Zero)
            throw new Exception("No se pudo abrir el .exe (esta en uso o sin permisos). Error " + Marshal.GetLastWin32Error());

        try
        {
            MemoryStream grp = new MemoryStream();
            BinaryWriter bw = new BinaryWriter(grp);
            bw.Write((ushort)0);
            bw.Write((ushort)1);
            bw.Write((ushort)count);

            for (int i = 0; i < count; i++)
            {
                int e = 6 + i * 16;
                byte w = d[e], hh = d[e + 1], cc = d[e + 2], res = d[e + 3];
                ushort planes = BitConverter.ToUInt16(d, e + 4);
                ushort bpp = BitConverter.ToUInt16(d, e + 6);
                uint size = BitConverter.ToUInt32(d, e + 8);
                uint off = BitConverter.ToUInt32(d, e + 12);
                if (planes == 0) planes = 1;

                byte[] img = new byte[size];
                Array.Copy(d, (int)off, img, 0, (int)size);

                // RT_ICON = 3
                if (!UpdateResource(h, (IntPtr)3, (IntPtr)(i + 1), 0, img, size))
                    throw new Exception("Fallo al escribir la imagen " + (i + 1));

                bw.Write(w); bw.Write(hh); bw.Write(cc); bw.Write(res);
                bw.Write(planes); bw.Write(bpp);
                bw.Write(size);
                bw.Write((ushort)(i + 1));
            }
            bw.Flush();
            byte[] g = grp.ToArray();

            // RT_GROUP_ICON = 14, nombre 1
            if (!UpdateResource(h, (IntPtr)14, (IntPtr)1, 0, g, (uint)g.Length))
                throw new Exception("Fallo al escribir el grupo de iconos");
        }
        catch
        {
            EndUpdateResource(h, true);   // descartar cambios
            throw;
        }

        if (!EndUpdateResource(h, false))
            throw new Exception("No se pudieron guardar los cambios. Error " + Marshal.GetLastWin32Error());
    }
}
'@

try {
    if (-not (Test-Path -LiteralPath $Exe)) { throw "No encuentro el archivo: $Exe" }
    if (-not (Test-Path -LiteralPath $Ico)) { throw "No encuentro el icono: $Ico" }

    $bak = "$Exe.original.bak"
    if (-not (Test-Path -LiteralPath $bak)) { Copy-Item -LiteralPath $Exe -Destination $bak }

    Add-Type -TypeDefinition $code
    [IconInjector]::Inject((Resolve-Path -LiteralPath $Exe).Path, (Resolve-Path -LiteralPath $Ico).Path)

    Write-Host ""
    Write-Host "  [OK] Icono agregado a: $Exe" -ForegroundColor Green
    Write-Host "  Copia de seguridad  : $bak" -ForegroundColor DarkGray

    # refrescar la cache de iconos de Windows
    try { & ie4uinit.exe -show 2>$null } catch {}
    try { & ie4uinit.exe -ClearIconCache 2>$null } catch {}
}
catch {
    Write-Host ""
    Write-Host "  [ERROR] $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}
