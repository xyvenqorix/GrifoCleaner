@echo off
REM Agrega GrifoCleaner.ico dentro de GrifoCleaner.exe (sin compilar, sin programas extra).
REM Pon este .bat, PonerIcono.ps1, GrifoCleaner.ico y GrifoCleaner.exe en la misma carpeta.
REM Tambien puedes arrastrar tu .exe encima de este .bat.

set "EXE=%~1"
if "%EXE%"=="" set "EXE=%~dp0GrifoCleaner.exe"

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0PonerIcono.ps1" -Exe "%EXE%" -Ico "%~dp0GrifoCleaner.ico"
echo.
pause
